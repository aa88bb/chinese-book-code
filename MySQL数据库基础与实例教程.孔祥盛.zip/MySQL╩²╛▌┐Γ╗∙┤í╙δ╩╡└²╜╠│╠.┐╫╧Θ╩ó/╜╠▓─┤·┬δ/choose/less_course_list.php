<?php
include_once("permission.php");
include_once("database.php");
if(is_admin()){
	$sql = "select * from course_teacher_view where up_limit-available<30";
	get_connection();
	$result_set = mysql_query($sql);
	$rows = mysql_num_rows($result_set);
	if($rows==0){
		$message = "������Ϣ��";
		header("Location:index.php?message=$message");
		//return;
	}else{
		echo "<table><tr><th>�κ�</th><th>�γ���</th><th>��������</th><th>�ον�ʦ</th><th>��ϵ��ʽ</th><th>��ѡ����</th><th>�γ�״̬</th><th>����</th></tr>";
		while($course_teacher=mysql_fetch_array($result_set)){
			echo "<tr>";
			$course_no = $course_teacher["course_no"];
			$course_name = $course_teacher["course_name"];
			$description = $course_teacher["description"];
			$status = $course_teacher["status"];
			echo "<td>".$course_no."</td>";
			echo "<td><a href='#' title=$description>".$course_name."</a></td>";
			echo "<td>".$course_teacher["up_limit"]."</td>";
			echo "<td>".$course_teacher["teacher_name"]."</td>";
			echo "<td>".$course_teacher["teacher_contact"]."</td>";
			echo "<td>".$course_teacher["available"]."</td>";
			echo "<td>".$course_teacher["status"]."</td>";
			echo "<td bgcolor='#F0F0F0'><a href=index.php?url=delete_course.php&course_no=$course_no>"."ɾ���ÿγ�"."</a></td>";
			echo "</tr>";
		}
	}
}else{
	$message = "�����ǹ���Ա��";
	header("Location:index.php?message=$message");
	//return;
}
?>
