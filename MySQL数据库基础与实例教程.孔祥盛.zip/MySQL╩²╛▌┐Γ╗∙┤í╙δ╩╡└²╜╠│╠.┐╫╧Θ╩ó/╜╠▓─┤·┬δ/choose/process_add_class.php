<?php
include_once("database.php");
$class_name = $_POST["class_name"];
$department_name = $_POST["department_name"];
$insert_sql = "insert into classes values (null,'$class_name','$department_name')";
get_connection();
mysql_query($insert_sql);
$affected_rows = mysql_affected_rows();
close_connection();
if($affected_rows>0){
	$message = "�༶���ӳɹ���";
}else{
	$message = "�༶����ʧ�ܣ�";
}
header("Location:index.php?message=$message");
?>
