<?php
include_once("permission.php");
include_once("database.php");
if(!is_teacher()){
	$message = "�����ǽ�ʦ��";
	header("Location:index.php?message=$message");	
}else{
	$account_no = $_SESSION["account_no"];
	get_connection();
	$sql = "call get_teacher_course_proc('$account_no');";
	$result_set = mysql_query($sql);
	$rows = mysql_num_rows($result_set);
	if($rows==0){
		$message = "����ʱû���걨�γ̣�";
		header("Location:index.php?message=$message");	
		return;
	}else{
		echo "<table><tr><th>�κ�</th><th>�γ���</th><th>�ον�ʦ</th><th>��ϵ��ʽ</th><th>״̬</th><th>����</th></tr>";
		while($course_teacher=mysql_fetch_array($result_set)){
			echo "<tr>";
			$course_no = $course_teacher["course_no"];
			$course_name = $course_teacher["course_name"];
			$teacher_name = $course_teacher["teacher_name"];
			$teacher_contact = $course_teacher["teacher_contact"];
			$description = $course_teacher["description"];
			$status = $course_teacher["status"];
			echo "<td>".$course_no."</td>";
			echo "<td><a href='#' title=$description>".$course_name."</a></td>";
			echo "<td>".$course_teacher["teacher_name"]."</td>";
			echo "<td>".$course_teacher["teacher_contact"]."</td>";
			echo "<td>".$status."</td>";
			if($status=="δ���"){
				echo "<td><a href='index.php?url=delete_course.php&course_no=$course_no'>ɾ���ÿγ�</a></td>";
			}else{
				echo "<td><a href='index.php?url=course_student_list.php&course_no=$course_no'>�鿴�ÿγ̵�ѧ����Ϣ</a></td>";
			}
			echo "</tr>";
		}
	}
	close_connection();
}	
?>
