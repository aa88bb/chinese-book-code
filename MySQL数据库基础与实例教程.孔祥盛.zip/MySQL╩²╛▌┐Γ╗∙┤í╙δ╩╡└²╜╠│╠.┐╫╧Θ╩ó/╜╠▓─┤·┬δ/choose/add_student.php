<form action="process_add_student.php" method="post">
ѧ�ţ�<input type="text" name="student_no"/><br/>
���룺<input type="password" name="password"/><br/>
ȷ�����룺<input type="password" name="re_password"/><br/>
������<input type="text" name="student_name"/><br/>
��ϵ��ʽ��<input type="text" name="student_contact"/><br/>
�༶��
<select name="class_id">
<?php
include_once("database.php");
get_connection();
$result_set = mysql_query("select * from classes");
close_connection();
while($row=mysql_fetch_array($result_set)){
?>
<option value="<?php echo $row['class_no'];?>"><?php echo $row['class_name'];?></option>
<?php
}
?>
</select>
<br/>
<input type="submit" value="ע��"/>
<input type="reset" value="����"/>
</form>
