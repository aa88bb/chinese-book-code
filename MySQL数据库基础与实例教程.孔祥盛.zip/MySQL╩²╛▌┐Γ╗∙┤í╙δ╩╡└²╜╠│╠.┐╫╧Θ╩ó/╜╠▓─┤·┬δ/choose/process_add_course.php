<?php
include_once("database.php");
$course_name = $_POST["course_name"];
$up_limit = $_POST["up_limit"];
$description = $_POST["description"];
$teacher_no = $_POST["teacher_no"];
$available = $up_limit;
$insert_sql = "insert into course values (null,'$course_name',$up_limit,to_english_fn('$description'),'δ���','$teacher_no',$available)";
get_connection();
mysql_query($insert_sql);
$affected_rows = mysql_affected_rows();
close_connection();
if($affected_rows>0){
	$message = "�γ����ӳɹ���";
}else{
	$message = "�γ�����ʧ�ܣ�";
}
header("Location:index.php?message=$message");
?>
