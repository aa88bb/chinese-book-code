<?php
include_once("database.php");
$account_no = $_POST["account_no"];
$new_password = $_POST["password"];
$role = $_POST["role"];
get_connection();
if($role=="student"){
	$sql = "update student set password=md5($new_password) where student_no='$account_no'";
}else if($role=="teacher"){
	$sql = "update teacher set password=md5($new_password) where teacher_no='$account_no'";
}
$result_set = mysql_query($sql);
$affected_rows = mysql_affected_rows();
close_connection();
if($affected_rows>0){
	$message = "�˺�$account_no"."�������޸�ʧ�ܣ�<br/>";
}else{
	$message = "�˺�$account_no"."�������޸ĳɹ���<br/>";
}
header("Location:index.php?message=$message");
?>
