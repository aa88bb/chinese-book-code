<?php
include_once("permission.php");
include_once("database.php");
get_connection();
$course_no = $_GET["course_no"];
if(is_teacher()){
	$teacher_no = $_SESSION["account_no"];
	//�жϸý�ʦ�Ƿ��ν����ſγ�
	$select_sql = "select course_no from course where course_no=$course_no and teacher_no='$teacher_no'"; 
	$result_set = mysql_query($select_sql);
	if(mysql_num_rows($result_set)==0){
		$message = "�������ον�ʦ��";
		header("Location:index.php?message=$message");
		//return;
	}
}
if(is_teacher() || is_admin()){
	$sql = "call get_course_student_proc($course_no);";
	$result_set = mysql_query($sql);
	$rows = mysql_num_rows($result_set);
	if($rows==0){
		$message = "���ſγ�����ѧ��ѡ�ޣ�";
		header("Location:index.php?message=$message");
		//return;
	}else{
		echo "<table><tr><th>Ժϵ</th><th>�༶</th><th>ѧ��</th><th>ѧ������</th><th>��ϵ��ʽ</th><th>����</th></tr>";
		while($student=mysql_fetch_array($result_set)){
			echo "<tr>";
			$department_name = $student["department_name"];
			$class_name = $student["class_name"];
			$student_no = $student["student_no"];
			$student_name = $student["student_name"];
			$student_contact = $student["student_contact"];
			echo "<td>".$department_name."</td>";
			echo "<td>".$class_name."</td>";
			echo "<td>".$student_no."</td>";
			echo "<td>".$student_name."</td>";
			echo "<td>".$student_contact."</td>";
			echo "<td><a href='index.php?url=quit_course.php&student_no=$student_no&course_no=$course_no'>ȡ����ѧ����ѡ��</a></td>";
			echo "</tr>";
		}
	}
	close_connection();
}else{
	$message = "����Ȩ�鿴��";
	header("Location:index.php?message=$message");
	//return;
}	
?>
