<?php
include_once("database.php");
$student_no = $_POST["student_no"];
$password = $_POST["password"];
$re_password = $_POST["re_password"];
$message = "";
if($password==$re_password){
	$student_name = $_POST["student_name"];
	$student_contact = $_POST["student_contact"];
	$class_id = $_POST["class_id"];
	$insert_sql = "insert into student values ('$student_no',md5('$password'),'$student_name','$student_contact',$class_id)";
	get_connection();
	mysql_query($insert_sql);
	$affected_rows = mysql_affected_rows();
	close_connection();
	if($affected_rows>0){
		$message = "ѧ�����ӳɹ���";
	}else{
		$message = "ѧ������ʧ�ܣ�";
	}
}else{
	$message = "������ȷ�����벻һ�£�ע��ʧ�ܣ�";
}
header("Location:index.php?message=$message");
?>
