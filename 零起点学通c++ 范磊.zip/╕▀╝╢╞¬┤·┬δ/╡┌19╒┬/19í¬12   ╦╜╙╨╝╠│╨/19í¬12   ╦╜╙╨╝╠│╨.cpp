#include <iostream>
using namespace std;
class A
{
public:
	void Set(int a,int b){x=a;y=b;}
	void Show(){cout<<x<<endl<<y<<endl;}
protected:
	int x;
private:
	int y;
};
class B:private A
{
public:
  void Set(int a,int b){A::Set(a,b);}
  void Show(){A::Show();}
};
class C:private B
{
public:
  void Set(int a,int b){B::Set(a,b);}
  void Show(){B::Show();}
};
int main()
{
   C c;
   c.Set(1,2);
   c.Show();
   return 0;
}
