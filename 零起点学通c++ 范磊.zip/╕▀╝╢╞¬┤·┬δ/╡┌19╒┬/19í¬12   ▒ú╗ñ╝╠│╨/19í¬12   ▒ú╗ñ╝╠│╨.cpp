#include <iostream>
using namespace std;
class A
{
public:
	void Set(int a,int b){x=a;y=b;}
	void Show(){cout<<x<<endl<<y<<endl;}
protected:
	int x;
private:
	int y;
};
class B:protected A
{
public:
	void Set(int a,int b){A::Set(a,b);x=0;}
	void Show(){A::Show();}
};
int main()
{
	B b;
    b.Set(1,2);
	b.Show();
	return 0;
}