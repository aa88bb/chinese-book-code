#include <iostream>
using namespace std;
class A
{
public:
	void Set(int a){x=a;}
	void Show(){cout<<x<<endl;}
protected:
	int x;
private:
	int y;
};
class B:public A
{
public:
	void Set(int a){x=a;}
	void Show(){cout<<x<<endl;}
};
int main()
{
	B b;
    b.Set(1);
	b.Show();
	return 0;
}