#include <iostream>
namespace people
{
 char name[10]="Jack";
}
namespace book
{
 char name[10]="Book";
}
int main()
{
 std::cout<<people::name;
 std::cout<<book::name;
 return 0;
}

