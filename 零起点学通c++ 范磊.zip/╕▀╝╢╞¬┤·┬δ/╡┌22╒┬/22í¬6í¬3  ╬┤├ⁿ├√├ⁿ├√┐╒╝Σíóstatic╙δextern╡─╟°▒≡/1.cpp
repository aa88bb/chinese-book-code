
int x=5;
