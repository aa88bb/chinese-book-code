#include<iostream>
//using namespace std;���ᳫ
int main()
{
	std::cout<<"�ᳫ\n";
	return 0;
}