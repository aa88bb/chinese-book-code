#include<iostream>
using namespace std;
namespace
{
	int x=2;
}
namespace
{
	int y=3;
}
int main()
{
	cout<<"x:"<<x<<" y:"<<y<<endl;
	return 0;
}
