#include <iostream>
namespace people
{
   void print(){std::cout<<"hello world";}
}
namespace people
{
   int x=3,y=4;
}
int main()
{
	people::print();
	std::cout<<"\n"<<people::x<<"\t"<<people::y<<std::endl;
	return 0;
}