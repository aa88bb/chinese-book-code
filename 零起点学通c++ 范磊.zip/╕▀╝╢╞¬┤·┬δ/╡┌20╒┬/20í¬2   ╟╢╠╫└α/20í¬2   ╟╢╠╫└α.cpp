#include <iostream>
using namespace std;
class rectangle
{
  public:
	class point
	{
		public:
			void setx(int X){x=X;}
			void sety(int Y){y=Y;}
			int getx()const{return x;}
			int gety()const{return y;}
		private:
			int x;
			int y;
	};
	point GetUpLeft()const{return upleft;}
	point GetLowLeft()const{return lowerleft;}
	point GetUpRight()const{return upright;}
	point GetLowRight()const{return lowerright;}

	rectangle(int top,int left,int bottom,int right);
	~rectangle(){}

	int GetTop()const{return Top;}
	int GetLeft()const{return Left;}
	int GetBottom()const{return Bottom;}
	int GetRight()const{return Right;}

	void SetUpLeft(){upleft.setx(Left);upleft.sety(Top);}
	void SetLowLeft(){lowerleft.setx(Left);lowerleft.sety(Bottom);}
	void SetUpRight(){upright.setx(Right);upright.sety(Top);}
	void SetLowRight(){lowerright.setx(Right);lowerright.sety(Bottom);}
	void SetTop(int top){Top=top;}
	void SetLeft(int left){Left=left;}
	void SetRight(int right){Right=right;}
	void SetBottom(int bottom){Bottom=bottom;}
	int GetArea()const{int width=Right-Left;int height=Bottom-Top; return(width*height);}

  private:
	point upleft;	
	point lowerleft;
	point upright;
	point lowerright;

	int Top;
	int Left;
	int Bottom;
	int Right;	
};

rectangle::rectangle(int top,int left,int bottom,int right)
{
	Top=top;
	Left=left;
	Bottom=bottom;
	Right=right;

	upleft.setx(Left);
	upleft.sety(Top);

	upright.setx(Right);
	upright.sety(Top);

	lowerright.setx(Right);
	lowerright.sety(Bottom);

	lowerleft.setx(Left);
	lowerleft.sety(Bottom);
}
class point 
{
  public:
	int GetArea(rectangle &rec){return rec.GetArea();}
};

int main()
{
	rectangle data(40,50,60,80);
	cout<<"���Ϊ��"<<data.GetLeft()<<endl;
	cout<<"�±�Ϊ��"<<data.GetBottom()<<endl;
	cout<<"���µ�x����Ϊ��"<<data.GetLowLeft().getx()<<endl;
	cout<<"���µ�y����Ϊ��"<<data.GetLowLeft().gety()<<endl;
	cout<<"�������Ϊ:"<<data.GetArea()<<endl;
	cout<<"��������Left��Bottomֵ"<<endl;
	data.SetLeft(0);
	data.SetBottom(100);
	data.SetLowLeft();
	cout<<"���Ϊ��"<<data.GetLeft()<<endl;
	cout<<"�±�Ϊ��"<<data.GetBottom()<<endl;
	cout<<"���µ�x����Ϊ��"<<data.GetLowLeft().getx()<<endl;
	cout<<"���µ�y����Ϊ��"<<data.GetLowLeft().gety()<<endl;
	point pt;
	cout<<"�������Ϊ:"<<pt.GetArea(data)<<endl;
	return 0;
}

