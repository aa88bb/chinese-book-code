//fill()�����ľ���Ӧ�õĳ���������£�
#include <iostream>
#include <algorithm>
#include<vector>
using namespace std;
template<class T>
class show 
{
	public:	
  void operator()(const T&t)
  {
  cout<<t<<" ";
  }
};
int main()
{
  show<int>one;
  vector<int>vone(10);
  fill(vone.begin(),vone.begin()+5,0);
  fill(vone.begin()+5,vone.end(),1);
  for_each(vone.begin(),vone.end(),one);
  cout<<"\n";
  return 0;
}

