#include <iostream>
#include <algorithm>
#include <vector>
#include <numeric>
using namespace std;
void show(int val)
{
  cout<<val<<endl;
}
int main()
{
  vector<int>one;
  for (int i=0;i<5;++i)
  {
    one.push_back(i);
  }
  vector<int>two(5);
  adjacent_difference(one.begin(),one.end(),two.begin());
  cout<<"���one�е�Ԫ��:\n";
  for_each(one.begin(),one.end(),show);
  cout<<"���two�е�Ԫ��:\n";
  for_each(two.begin(),two.end(),show);
}
