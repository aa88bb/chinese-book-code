#include <iostream>
#include <algorithm>
#include <vector>
#include <numeric>
using namespace std;
void show(int val)
{
  cout<<val<<endl;
}
int main()
{
  vector<int>one;
  for (int i=0;i<5;++i)
  {
    one.push_back(i);
  }
  for_each(one.begin(),one.end(),show);
  int result=accumulate(one.begin(),one.end(),5);
  cout<<"����5������5��ӵĽ��Ϊ��"<<result;
}
