#include <iostream>
#include <algorithm>
using namespace std;
int main()
{
 int a[] = {2,1,3};
 do
 {
     cout<< a[0] << " " << a[1] << " " << a[2] << endl;
 }
 while (prev_permutation(a,a+3));
 return 0;
}
