#include<algorithm> 
#include<set>
#include<iostream>
#include<iterator>
using namespace std; 
int   main() 
{ 
	int x[]={1,3,5,7,9};
	int y[]={2,4,6,8,9};
	multiset<int>first1(x,x+sizeof(x)/sizeof(int));
	multiset<int>first2(y,y+sizeof(y)/sizeof(int));
	transform(first1.begin(),first1.end(),first2.begin(),ostream_iterator<int>(cout," "),plus<int>());
	cout<<endl;
	return 0;
}
