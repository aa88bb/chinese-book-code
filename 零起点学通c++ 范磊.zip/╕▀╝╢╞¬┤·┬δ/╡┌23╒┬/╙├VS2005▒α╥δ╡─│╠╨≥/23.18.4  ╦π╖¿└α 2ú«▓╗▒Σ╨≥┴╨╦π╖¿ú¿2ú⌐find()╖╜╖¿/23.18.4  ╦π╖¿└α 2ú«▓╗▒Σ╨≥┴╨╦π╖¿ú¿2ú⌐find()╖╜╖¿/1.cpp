#include <iostream>
#include <string> 
#include <list> 
#include <algorithm> 
using namespace std;
int main (void) 
{ 
  list<string> str; 
  list<string>::iterator it; 
  str.push_back("ѧ��"); 
  str.push_back("��ʦ"); 
  str.push_back("У��"); 
  it = find (str.begin(), str.end(), "У��"); 
  if (it == str.end()) 
  { 
   cout << "û���ҵ���У����\n"; 
  } 
  else 
  { 
   cout << *it << endl; 
  } 
  system("pause");
  return 0;
} 
