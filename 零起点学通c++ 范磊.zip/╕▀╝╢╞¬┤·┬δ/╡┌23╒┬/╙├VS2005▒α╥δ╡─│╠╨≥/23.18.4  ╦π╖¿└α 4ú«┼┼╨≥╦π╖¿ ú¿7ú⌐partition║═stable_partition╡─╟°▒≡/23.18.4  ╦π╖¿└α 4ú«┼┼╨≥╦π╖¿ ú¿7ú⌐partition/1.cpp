#include <iostream>
#include <algorithm>
#include <functional>
#include <vector>
#include <string>
using namespace std;
class student
{
  public:
    student(const string &a, int b):name(a), score(b){}
    string name;
    int score;
    bool operator < (const student &m)const 
    {
		return name.length()< m.name.length();
    }
	bool operator==(const student&s)const
	{
		return score<s.score;
	}
};
int main()
{
  vector< student> one;
  student str("����", 74);
  one.push_back(str);
  str.name="��ʤ";
  str.score=100;
  one.push_back(str);
  str.name="���ݻ�";
  str.score=52;
  one.push_back(str);
  str.name="������";
  str.score=85;
  one.push_back(str);
  str.name="��ʤɽ";
  str.score=48;
  one.push_back(str);
  str.name="����";
  str.score=99;
  one.push_back(str);
  str.name="Ǯ���";
  str.score=77;
  one.push_back(str);
  str.name="���˾�";
  str.score=24;
  one.push_back(str);
  str.name="������";
  str.score=76;
  one.push_back(str);
  str.name="·��";
  str.score=80;
  one.push_back(str);
  cout<<"------����stable_partition����ǰ..."<<endl;
  for(int i = 0 ; i < one.size(); i ++) 
  cout<<one[i].name<<":\t"<<one[i].score<<endl;
  student two("���˾�", 60);
  stable_partition(one.begin(),one.end(), bind2nd(less<student>(),two));
  cout <<"-----����stable_partition������...."<<endl;
  for(int i = 0 ; i < one.size(); i ++) 
  cout<<one[i].name<<":\t"<<one[i].score<<endl;

  partition(one.begin(),one.end(), bind2nd(less<student>(),two));
  cout <<"-----����partition������...."<<endl;
  for(int i = 0 ; i < one.size(); i ++) 
  cout<<one[i].name<<":\t"<<one[i].score<<endl;
  return 0 ;
}
