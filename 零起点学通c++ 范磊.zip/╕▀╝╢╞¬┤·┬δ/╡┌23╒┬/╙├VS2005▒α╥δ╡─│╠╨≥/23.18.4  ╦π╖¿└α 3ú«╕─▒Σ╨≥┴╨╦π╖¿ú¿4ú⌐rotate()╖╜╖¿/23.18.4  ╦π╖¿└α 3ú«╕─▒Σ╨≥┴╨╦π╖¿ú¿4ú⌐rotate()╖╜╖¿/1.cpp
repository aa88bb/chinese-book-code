//rotate ()�����ľ���Ӧ�����̴������£�
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
void show(char val)
{
  cout<<val;
}
int main()
{
  vector<char>one;
  one.push_back('h');
  one.push_back('e');
  one.push_back('l');
  one.push_back('l');
  one.push_back('o');
  one.push_back('w');
  one.push_back('o');
  one.push_back('r');
  one.push_back('l');
  one.push_back('d');
  for_each(one.begin(),one.end(),show);
  cout<<"\nrotate\n";
  rotate(one.begin(),one.begin()+5,one.end());
  for_each(one.begin(),one.end(),show);
  return 0;
}
