#include <iostream>
using  namespace std;
const int size=10;
template <template <class T> class TT,class T> 
ostream & operator << (ostream &out, const TT<T> &tt);

template<class T>
class num 
{
	public:
	  num(int Tsize=size);
	  ~num(){delete[]pt;}
	  num&operator=(const num&);
	  T&operator[](int offset){return pt[offset];}
	  const T&operator[](int offset)const
	  {
		return pt[offset];
	  }
	  int GetSize() const {return numsize;}
	  friend ostream & operator << <>(ostream &out, const num<char> &tt); 
	private:
	  int numsize;
	  T*pt;
};    

ostream & operator << (ostream &out, const num<char> &tt)
{
	out<<"�����ض�ģ����Ԫ����operator<<...\n";
	for (int i=0;i<tt.GetSize();i++)
	{
		out<<tt[i];
	}
	out<<endl;
	return out;
}
template <template <class T> class TT,class T> 
ostream & operator << (ostream &out, const TT<T> &tt)
{
	out<<"����ͨ��ģ����Ԫ����operator<<...\n";
	for (int i=0;i<tt.GetSize();i++)
	{
		out<<"["<<tt[i]<<"]"<<endl;
	}
	return out;
}
template<class T>
num<T>::num(int size):numsize(size)
{
	pt=new T[size];
	for (int i=0;i<size;i++)
	{
		pt[i]=0;
	}
}
template<class T>
num<T>&num<T>::operator=(const num&r)
{
	if (this==&r)
	{
		return *this;
		delete[]pt;
		numsize=r.GetSize();
		pt=new T[numsize];
		for (int i=0;i<numsize;i++)
		{
			pt[i]=r[i];
		}
	}
	return *this;
}

template<class T>
class num1 
{
	public:
	  num1(int Tsize=size);
	  ~num1(){delete[]pt;}
	  num1&operator=(const num1&);
	  T&operator[](int offset){return pt[offset];}
	  const T&operator[](int offset)const
	  {
		return pt[offset];
	  }
	  int GetSize() const {return numsize;}
	private:
	  int numsize;
	  T*pt;
};
template<class T>
num1<T>::num1(int size):numsize(size)
{
	pt=new T[size];
	for (int i=0;i<size;i++)
	{
		pt[i]=0;
	}
}
template<class T>
num1<T>&num1<T>::operator=(const num1&r)
{
	if (this==&r)
	{
		return *this;
		delete[]pt;
		numsize=r.GetSize();
		pt=new T[numsize];
		for (int i=0;i<numsize;i++)
		{
			pt[i]=r[i];
		}
	}
	return *this;
}
int main()
{
	num<char>one;
	num<int>two;
	num1<float>three;
	for (int i=0;i<one.GetSize();i++)
	{
		one[i]=i+38;	
		two[i]=i*3;
		three[i]=i;
	}
	cout<<one;
	cout<<two;
	cout<<three;
	system("pause");
	return 0;
}
