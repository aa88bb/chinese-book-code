#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
void show(char&t)
{
  cout<<t<<" ";
}
int main()
{
  vector<char>one;
  one.push_back('z');
  one.push_back('c');
  one.push_back('b');
  one.push_back('o');
  one.push_back('p');
  one.push_back('t');
  one.push_back('i');
  one.push_back('w');
  one.push_back('x');
  one.push_back('b');
  vector<char>two;
   two.push_back('z');
  two.push_back('c');
  two.push_back('b');
  one.push_back('o');
  one.push_back('p');
  one.push_back('t');
  one.push_back('i');
  one.push_back('w');
  one.push_back('x');
  one.push_back('b');
  for_each(one.begin(),one.end(),show);
  partial_sort(one.begin(),one.begin()+5,one.end());
  cout<<"\n���������\n";
  for_each(one.begin(),one.end(),show);
  return 0;
}
