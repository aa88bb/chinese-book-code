//partition()�����ľ���Ӧ�����̴������£�
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
void show(int val)
{
  cout<<val<<endl;
}
bool Equal(int val)
{
  return (val==5);
}
int main()
{
  vector<int>one;
  one.push_back(1);
  one.push_back(3);
  one.push_back(5);
  one.push_back(6);
  one.push_back(5);
  one.push_back(4);
  one.push_back(5);
  for_each(one.begin(),one.end(),show);
  cout<<"partition\n";
  partition(one.begin(),one.end(),Equal);
  for_each(one.begin(),one.end(),show);
  return 0;
}


