#include <iostream>
#include <string> 
#include <map> 
#include <algorithm> 
using namespace std;
typedef map<string,string>::const_iterator CIT;
typedef map<string,string>::value_type VT;
class func 
{ 
  public: 
  bool operator () (VT&vt)
  { 
   return vt.second=="1858"; 
  } 
}; 
int main () 
{ 
  map<string,string>one;
  one.insert(VT("������������","1897"));
  one.insert(VT("���������","1858"));
  one.insert(VT("�����콢����","1869"));
  CIT cit=find_if(one.begin(),one.end(),func());
  if (cit==one.end()) 
  { 
   cout << "û���ҵ�...\n"; 
  } 
  else 
  { 
   cout<<cit->second<<"\t"<<cit->first<< endl; 
  }
  system("pause");
  return 0;
}

