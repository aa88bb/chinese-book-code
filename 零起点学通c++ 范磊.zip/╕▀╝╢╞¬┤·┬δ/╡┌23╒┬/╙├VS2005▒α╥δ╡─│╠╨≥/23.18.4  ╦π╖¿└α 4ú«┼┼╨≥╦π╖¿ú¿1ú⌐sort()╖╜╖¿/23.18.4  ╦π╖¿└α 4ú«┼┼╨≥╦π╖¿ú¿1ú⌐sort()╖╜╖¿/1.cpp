#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
void show(char&t)
{
   cout<<t<<" ";
}
int main()
{
   vector<char>one;
   one.push_back('h');
   one.push_back('e');
   one.push_back('l');
   one.push_back('l');
   one.push_back('o');
   for_each(one.begin(),one.end(),show);
   sort(one.begin(),one.end());
   cout<<"\n���������\n";
   for_each(one.begin(),one.end(),show);
   return 0;
}


