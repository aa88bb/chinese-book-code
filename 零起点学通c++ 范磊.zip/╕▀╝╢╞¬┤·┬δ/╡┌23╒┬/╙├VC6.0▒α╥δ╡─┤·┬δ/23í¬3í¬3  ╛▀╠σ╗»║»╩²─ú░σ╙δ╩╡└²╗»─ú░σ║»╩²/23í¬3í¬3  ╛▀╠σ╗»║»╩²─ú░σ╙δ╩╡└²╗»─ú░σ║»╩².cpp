#include <iostream>
using namespace std;
template<class T>
void show(T a){cout<<a<<endl;}
template void show<char&>(char&);
int main()
{
 show(5);
 return 0;
}
