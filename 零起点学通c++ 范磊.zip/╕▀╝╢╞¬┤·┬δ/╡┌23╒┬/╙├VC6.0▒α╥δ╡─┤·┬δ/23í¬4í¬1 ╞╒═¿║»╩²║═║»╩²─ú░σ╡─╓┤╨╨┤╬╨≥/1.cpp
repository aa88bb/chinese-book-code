#include <iostream>
using namespace std;
template<class T>
void show(T a){cout<<"ģ�庯��!"<<a<<endl;}
void show(int a){cout<<"��ģ�庯��!"<<a<<endl;}
int main()
{
   show(5);
   return 0;
}
