#include <iostream>
#include<fstream>
using namespace std;
const int num=20;
struct people
{
  char name[num];
  double weight;
  int tall;
  int age;
  char sex;
};
int main()
{
  people pe={"����",78.5,181,25,'f'};
  ofstream fout("people.txt",ios::binary);
  fout.write((char*)&pe,sizeof pe);
  fout.close();
  people pe1={"����",65.4,165,62,'m'};
  ifstream fin("people.txt",ios::binary);
  fin.read((char*)&pe1,sizeof pe1);
  cout<<pe1.name<<" "<<pe1.age<<" "<<pe1.sex<<" "<<pe1.tall<<" " 
    << pe1.weight <<" "<<"\n";
  fin.close();
  return 0;
}
