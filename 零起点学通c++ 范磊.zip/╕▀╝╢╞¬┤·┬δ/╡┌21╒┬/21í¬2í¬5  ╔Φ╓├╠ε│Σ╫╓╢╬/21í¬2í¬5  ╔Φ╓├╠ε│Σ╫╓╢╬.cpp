#include <iostream>
using namespace std;
int main()
{
 cout.width(20);
 cout.fill('*');
 cout<<"help"<<endl;
 cout.width(25);
 cout<<"help"<<endl;
 return 0;
}
