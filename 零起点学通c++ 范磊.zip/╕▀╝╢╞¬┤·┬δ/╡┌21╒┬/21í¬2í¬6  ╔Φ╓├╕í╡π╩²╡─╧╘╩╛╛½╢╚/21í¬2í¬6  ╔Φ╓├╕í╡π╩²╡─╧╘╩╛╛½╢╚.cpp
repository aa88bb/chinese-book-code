#include <iostream>
using namespace std;
int main()
{
	float pi=3.1415926f;
	float p2=9876.622345f;
	cout<<pi<<endl;
	cout<<p2<<endl;
	cout.precision(15);
	cout<<pi<<endl;
	cout<<p2<<endl;
	cout.precision(3);
	cout<<pi<<endl;
	cout<<p2<<endl;
	return 0;
}
