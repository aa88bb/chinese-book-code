#include <iostream>
using namespace std;
int main()
{
    int x;
    cin>>hex>>x;
    cout<<x;
    system("PAUSE");
    return 0;
}
