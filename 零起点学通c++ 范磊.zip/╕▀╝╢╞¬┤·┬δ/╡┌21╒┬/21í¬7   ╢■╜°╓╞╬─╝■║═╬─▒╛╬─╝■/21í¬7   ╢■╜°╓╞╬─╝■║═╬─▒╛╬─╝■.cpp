#include <iostream>
using namespace std;
int main()
{
    int ch='2';
	cout<<ch<<endl;
	return 0;
}