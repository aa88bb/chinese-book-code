#include <iostream>
#include<fstream>
using namespace std;
const int num=20;
struct people
{
  char name[num];
  double weight;
  int tall;
  int age;
  char sex;
};
int main()
{
    people pe={"����",78.5,181,25,'f'};
    ofstream fout("people.dat",ios::out|ios::app);
    fout<<pe.name<<" "<<pe.age<<" "<<pe.sex<<" "<<pe.tall<<" "<< 
         pe.weight<<" "<<"\n";
    fout.close();
    ifstream fin("people.dat");
    char ch[255];
    fin.getline(ch,255-1,0);
    cout<<ch;
    fin.close();
    return 0;
}
