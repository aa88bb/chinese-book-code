#include <iostream>
using namespace std;
int main()
{
   char word[12];
   cin>>word;
   cout<<word<<endl;
   return 0;
}
