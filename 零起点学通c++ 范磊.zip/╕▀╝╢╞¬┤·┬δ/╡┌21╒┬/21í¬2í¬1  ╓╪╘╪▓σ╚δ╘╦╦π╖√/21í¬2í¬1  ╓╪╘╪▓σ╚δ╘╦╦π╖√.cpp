#include <iostream>
using namespace std;
int main()
{
	//char*ch="hello world";
	//cout<<(void*)ch<<endl;
	//cout<<&ch;

	//char ch[12]="hello world";
    //cout<<(void*)ch<<endl;
    //cout<<&ch;

	char*p="��";
	if ((unsigned char)*p > 127)  //���� 
	{ 
		cout<<"�Ǻ���\n";
	} 
	else  //��׼��ASCII�ַ� 
	{ 
		cout<<"���Ǻ���\n";
	} 
	
	//char*ch1="hello world";
	//char ch2[12]="hello world";
    //cout<<ch1<<ch2<<endl;

	return 0;
}
