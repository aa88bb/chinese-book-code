// wabSet.cpp : implementation of the CWabSet class
//

#include "stdafx.h"
#include "wab.h"
#include "wabSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWabSet implementation

IMPLEMENT_DYNAMIC(CWabSet, CRecordset)

CWabSet::CWabSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CWabSet)
	m_ID = 0;
	m_NAME = _T("");
	m_ADDRESS = _T("");
	m_TEL = _T("");
	m_TIME = 0;
	m_nFields = 5;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dynaset;
}

CString CWabSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=wab");
}

CString CWabSet::GetDefaultSQL()
{
	return _T("[wab]");
}

void CWabSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CWabSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[ID]"), m_ID);
	RFX_Text(pFX, _T("[NAME]"), m_NAME);
	RFX_Text(pFX, _T("[ADDRESS]"), m_ADDRESS);
	RFX_Text(pFX, _T("[TEL]"), m_TEL);
	RFX_Date(pFX, _T("[TIME]"), m_TIME);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CWabSet diagnostics

#ifdef _DEBUG
void CWabSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CWabSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
