// wabDoc.cpp : implementation of the CWabDoc class
//

#include "stdafx.h"
#include "wab.h"

#include "wabSet.h"
#include "wabDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWabDoc

IMPLEMENT_DYNCREATE(CWabDoc, CDocument)

BEGIN_MESSAGE_MAP(CWabDoc, CDocument)
	//{{AFX_MSG_MAP(CWabDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWabDoc construction/destruction

CWabDoc::CWabDoc()
{
	// TODO: add one-time construction code here

}

CWabDoc::~CWabDoc()
{
}

BOOL CWabDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CWabDoc diagnostics

#ifdef _DEBUG
void CWabDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CWabDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CWabDoc commands
