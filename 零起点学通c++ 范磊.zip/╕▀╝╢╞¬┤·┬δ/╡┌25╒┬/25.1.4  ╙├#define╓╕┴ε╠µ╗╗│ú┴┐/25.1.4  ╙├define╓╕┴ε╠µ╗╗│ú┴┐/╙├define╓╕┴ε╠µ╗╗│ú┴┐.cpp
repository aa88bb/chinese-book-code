#include<iostream>
#define Two 2
using namespace std;
int main()
{
	int num =Two;
	cout<<num<<endl;
	return 0;
}