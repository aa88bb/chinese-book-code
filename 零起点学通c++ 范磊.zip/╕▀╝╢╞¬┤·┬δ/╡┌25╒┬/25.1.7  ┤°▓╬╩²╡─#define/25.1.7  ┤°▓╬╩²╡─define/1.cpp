#include <iostream>
#define func(x) ((x)*2)
using namespace std;
int main()
{
  int x=func(9);
  cout<<x<<endl;
  return 0;
}

