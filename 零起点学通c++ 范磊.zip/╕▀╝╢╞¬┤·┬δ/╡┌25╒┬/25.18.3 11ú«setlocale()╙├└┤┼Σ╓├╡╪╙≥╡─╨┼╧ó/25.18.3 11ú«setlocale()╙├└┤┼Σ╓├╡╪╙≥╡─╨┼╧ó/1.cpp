#include <locale.h>
#include <iostream>
int main(void)
{
  std::cout<<setlocale(LC_ALL,"Japanese");
  return 0;
}
