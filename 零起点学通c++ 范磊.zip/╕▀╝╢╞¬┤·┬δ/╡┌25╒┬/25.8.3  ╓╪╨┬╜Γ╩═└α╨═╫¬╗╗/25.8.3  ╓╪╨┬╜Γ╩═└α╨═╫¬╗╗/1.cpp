#include <iostream>
using namespace std;
void *p()
{
	static char ch[20];
	return ch;
}
int main()
{
	char*cp=reinterpret_cast<char*>(p());
	strcpy(cp,"hello,world");
	cout<<cp<<endl;

	//��ָ��ת��Ϊ��ֵ
	int n=reinterpret_cast<int>(cp);
    cout<<n<<endl;
	//����ֵת��Ϊָ��
    cp=reinterpret_cast<char*>(n);
    cout<<cp<<endl;

	return 0;
} 

