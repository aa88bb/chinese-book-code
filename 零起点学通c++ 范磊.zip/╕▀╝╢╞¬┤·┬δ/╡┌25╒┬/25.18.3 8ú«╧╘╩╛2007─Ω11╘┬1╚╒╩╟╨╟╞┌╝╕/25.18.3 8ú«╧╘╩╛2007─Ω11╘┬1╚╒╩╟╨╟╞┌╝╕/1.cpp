#include <time.h>
#include <iostream>
using namespace std;
int main()
{
	struct tm t;
	time_t day;
	t.tm_year=2007-1900;
	t.tm_mon=10;
	t.tm_mday=1;
	t.tm_hour=18;
	t.tm_min=52;
	t.tm_sec=0;
	t.tm_isdst=0;
	day=mktime(&t);
	cout<<ctime(&day);
	return 0;
}
