#include<iostream>
using namespace std;
int main()
{
	int a=10;
	a<<=2;
	cout<<a<<endl;
    int b=1;
	a|=b;
	cout<<a<<endl;
	return 0;
}