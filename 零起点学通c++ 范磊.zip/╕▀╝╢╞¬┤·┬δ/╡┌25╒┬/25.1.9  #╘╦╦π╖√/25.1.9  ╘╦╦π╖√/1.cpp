#include<iostream>
using namespace std;
#define show(x)cout<<#x;
int main()
{
	show(hello world);
	return 0;
}