#include <iostream>
 using namespace std;
  int main()
 {
  	int ch[2][3]=
     {
		{0,1,2},
    	{10,11,12}
     };
  int *p1=&ch[1][2];
  int*p2=ch[1]+2;
  int*p3=ch[0];
  int*p4=ch[1];
  cout<<*p1<<" "
  <<*p2<<" "
  <<*p3<<" "
  <<*p4<<endl;
  return 0;
}
