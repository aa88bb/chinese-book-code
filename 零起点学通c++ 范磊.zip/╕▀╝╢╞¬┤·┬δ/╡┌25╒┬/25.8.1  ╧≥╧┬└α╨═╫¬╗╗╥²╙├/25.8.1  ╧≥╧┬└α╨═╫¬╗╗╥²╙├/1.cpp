#include <iostream>
using namespace std;
class Father 
{
	public:
	  virtual void Run (){cout<<"�����ܵÿ�\n";}
};
class Son:public Father 
{
	public:
	  virtual void Run()
	  {
		cout<<"�����ܵñȸ��׿�\n";
	  }
};
void fun(Father&r)
{
	try
	{
		Son&p=dynamic_cast<Son&>(r);
		p.Run();
	}
	catch (bad_cast)
	{
		cout<<"ת��ʧ��\n";
	}
	catch (...) 
	{
		cout<<"ת������\n";
	}
}
int main()
{
	Father pFather;
	Son son;
	fun(son);
	fun(pFather);
	return 0;
}

