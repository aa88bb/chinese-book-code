#include "one.h"
class son:public father
{
};
