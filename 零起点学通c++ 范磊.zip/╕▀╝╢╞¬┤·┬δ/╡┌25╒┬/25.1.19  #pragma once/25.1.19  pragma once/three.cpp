#include "three.h"
int main()
{ 
	grandson a;
	a.show();
}
