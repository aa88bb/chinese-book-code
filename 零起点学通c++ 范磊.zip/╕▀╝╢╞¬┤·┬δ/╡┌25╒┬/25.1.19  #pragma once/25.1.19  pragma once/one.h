#pragma once
//#ifndef one
//#define one

#include <iostream>
using namespace std;
class father
{
  public:
	father(){n=0;}
	void show()
	{
		cout<<n<<endl;
	}
  private:
	int n;
};

//#endif