#include "one.h"
#include "two.h"
class grandson:public son
{
};
