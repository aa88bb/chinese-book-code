#include <iostream>
using namespace std;
void copy(char *a,char *b)
{	
	for (;*a!=0;a++,b++)
	{
		*b=*a;
	}
	*b='\0';
}

int main()
{
	char ch1[]="Hello world",ch2[20];
	copy(ch1,ch2);
	cout<<"ch1:"<<ch1<<endl;
	cout<<"ch2:"<<ch2<<endl;
	return 0;
} 