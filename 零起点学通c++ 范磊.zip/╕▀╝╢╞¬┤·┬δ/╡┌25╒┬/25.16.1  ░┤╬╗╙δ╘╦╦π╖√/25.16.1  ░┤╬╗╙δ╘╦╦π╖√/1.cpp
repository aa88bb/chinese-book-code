#include<iostream>
#include <bitset>

using namespace std;
int main()
{
	cout<<"1&1:"<<(1&1)<<endl;
	cout<<"1&0:"<<(1&0)<<endl;
	cout<<"0&1:"<<(0&1)<<endl;
	cout<<"0&0:"<<(0&0)<<endl;
	cout<<"1&2:"<<(1&2)<<endl;

	//��1�������еĶ�����λ����
	bitset<8>   num1(85),num2(0);   
	cout<<num1<<"&"<<num2<<":"<<(num1&num2)<<endl;
	
	//��2��ȡָ��λ
   
    bitset<8>   num3(73),num4(85);   
	cout<<num3<<"&"<<num4<<":"<<(num3&num4)<<endl;
    
	//ȡ��4λ
	bitset<8>   num5(73),num6(15);   
	cout<<num5<<"&"<<num6<<":"<<(num5&num6)<<endl;

	//ȡ��4λ
	bitset<8>   num7(73),num8(240);   
	cout<<num7<<"&"<<num8<<":"<<(num7&num8)<<endl;
	return 0;
}