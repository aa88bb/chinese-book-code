#include <iostream>
using namespace std;
void copy(char a[],char b[])
{
	int i;
   for (i=0;a[i]!=0;i++)
	{
		b[i]=a[i];
	}
	b[i]='\0';
}
int main()
{
	char ch1[]="Hello world",ch2[20];
	copy(ch1,ch2);
	cout<<"ch1:"<<ch1<<endl;
	cout<<"ch2:"<<ch2<<endl;
	return 0;
} 

