#include <iostream>
using namespace std;
class Father 
{
	public:
	  virtual void Run (){cout<<"�����ܵÿ�\n";}
};
class Son:public Father 
{
	public:
	  virtual void Run()
	  {
		cout<<"�����ܵñȸ��׿�";
	  }
};
int main()
{
	Father*pFather;
	int choice;
	cout<<"(1)Father(2)Son:";
	cin>>choice;
	if (choice==2)
	{
		pFather=new Son;
	}
	else
		pFather=new Father;
	Son*p=dynamic_cast<Son*>(pFather);
	if (p)
	{
		p->Run();
	}
	else
		cout<<"ת��ʧ��\n";
	delete pFather;
	return 0;
} 
