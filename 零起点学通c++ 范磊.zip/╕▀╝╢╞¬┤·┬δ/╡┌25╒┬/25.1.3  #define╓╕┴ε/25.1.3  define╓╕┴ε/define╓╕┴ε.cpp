#include<iostream>
#include"define.h"
using namespace std;
int main()
{
	int ch[Two]={0,1};
	cout<<ch[0]<<"\t"<<ch[1]<<endl;
	return 0;
}