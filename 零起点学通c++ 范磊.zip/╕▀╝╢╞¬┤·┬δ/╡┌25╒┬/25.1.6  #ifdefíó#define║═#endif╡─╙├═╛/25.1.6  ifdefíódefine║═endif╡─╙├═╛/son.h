#include"father.h"
#ifndef SON_H
#define SON_H

class son:public father
{
public:
	void show(){std::cout<<"���ӷ���\n";}
};
#endif