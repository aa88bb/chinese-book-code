#include<iostream>
#include"son.h"
#include"grandson.h"
int main()
{
	grandson g;
	g.show();
	son s;
	s.show();
	father f;
	f.show();
	return 0;
}