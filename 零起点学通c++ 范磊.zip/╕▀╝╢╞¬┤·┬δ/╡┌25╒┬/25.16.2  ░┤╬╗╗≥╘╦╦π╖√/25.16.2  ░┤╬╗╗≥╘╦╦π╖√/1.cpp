#include<iostream>
#include <bitset>

using namespace std;
int main()
{
	cout<<"1|1:"<<(1|1)<<endl;
	cout<<"1|0:"<<(1|0)<<endl;
	cout<<"0|1:"<<(0|1)<<endl;
	cout<<"0|0:"<<(0|0)<<endl;
	cout<<"1|2:"<<(1|2)<<endl;
    bitset<8>num1(65),num2(15);
	cout<<num1<<"|"<<num2<<":"<<(num1|num2)<<endl;
	return 0;
}