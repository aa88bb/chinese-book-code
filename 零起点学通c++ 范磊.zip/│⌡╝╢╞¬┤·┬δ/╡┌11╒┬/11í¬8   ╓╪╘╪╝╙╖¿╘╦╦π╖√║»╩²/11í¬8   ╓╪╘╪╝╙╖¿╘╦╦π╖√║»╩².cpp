//ģ��ӷ������������add()����
/*
#include <iostream>
using namespace std;
class num 
{
public:
    num(){}
    num(int i){n=i;}
    int get()const{return n;}
    void set(int x){n=x;}
    num add(const num&r){return num(n+r.get());}

private:
    int n;
};
int main()
{
    num one(1),two(2),three;
    three=one.add(two);
    cout<<"one:"<<one.get()<<endl;
    cout<<"two:"<<two.get()<<endl;
    cout<<"three:"<<three.get()<<endl;
    return 0;
}
*/


//ʹ������operator+��������������£�
#include <iostream>
using namespace std;
class num 
{
public:
    num(){}
    num(int i){n=i;}
    int get()const{return n;}
    void set(int x){n=x;}
    const num operator+(const num&r){return num(n+r.get());}
private:
    int n;
};
int main()
{
    num one(1),two(2),three;
    three=one+two;
    cout<<"one:"<<one.get()<<endl;
    cout<<"two:"<<two.get()<<endl;
    cout<<"three:"<<three.get()<<endl;
    return 0;
}
