#include <iostream>
using namespace std;
class num 
{
public:
    num(){n=1;cout<<"���캯��ִ��\n";}
    num(const num &s){this->n=s.n;cout<<"���ƹ��캯��ִ��\n";}
    num(int i){n=i;cout<<"���캯��ִ��\n";}
    ~num(){cout<<"��������ִ��\n";}
    int get()const{return n;}
    void set(int x){n=x;}
    void add(){n++;}
const num &operator++(){++n;return *this;}
const num operator++(int o){num temp(*this);++n;return temp;}
private:
    int n;
};
int main()
{
    num i;
    cout<<"i:"<<i.get()<<endl;
    num x=++i;
    cout<<"x:"<<x.get()<<endl;
    cout<<"i:"<<i.get()<<endl;
    x=i++;
    cout<<"x:"<<x.get()<<endl;
    cout<<"i:"<<i.get()<<endl;
    return 0;
}

