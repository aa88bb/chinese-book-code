#include<iostream>
void main()
{
	int a[5];
    int i;
	for (i=0;i<5;i++)
	{
		a[i]=i;
	}
	for (i=0; i<5; i++)
		std::cout<<a[i]<<"\n";
}
