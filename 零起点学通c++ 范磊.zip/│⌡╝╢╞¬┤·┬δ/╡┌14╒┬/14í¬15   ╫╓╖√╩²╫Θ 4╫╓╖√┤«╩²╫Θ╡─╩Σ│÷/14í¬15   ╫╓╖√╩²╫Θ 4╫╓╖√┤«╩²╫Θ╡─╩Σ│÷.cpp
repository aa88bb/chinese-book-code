#include<iostream>
using namespace std;
void main()
{
	char c[40]={"hello world"};
	cout<<c;
}
