#include<iostream>
using namespace std;
void main()
{
  int a[4]={1,2,3,4};
  cout<<a<<"\n";
}

