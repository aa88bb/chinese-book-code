#include<iostream>
using namespace std;
void main()
{
  int a[5][2]={{1,10},{2,20},{3,30},{4,40},{5,50}};
  for (int i=0;i<5;i++)
	for (int j=0;j<2;j++)
	{
	  cout<<"a["<<i<<"]["<<j<<"]:"<<a[i][j]<<endl;
	}
}
