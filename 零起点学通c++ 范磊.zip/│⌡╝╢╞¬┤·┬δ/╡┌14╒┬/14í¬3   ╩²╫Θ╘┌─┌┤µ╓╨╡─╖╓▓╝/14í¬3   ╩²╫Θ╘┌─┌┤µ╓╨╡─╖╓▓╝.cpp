#include<iostream>
void main()
{
	int a[2];
	int b[10];
	b[10]=3;
	std::cout<<"b[10] = "<<b[10]<<std::endl;
	std::cout<<"a[0] = "<<a[0]<<std::endl;
}
