#include <iostream>
using namespace std;
int main()
{
	char a[20]="My name is";
	char b[]=" Jack.";
	std::cout<<strcat(a,b);
	return 0;
}