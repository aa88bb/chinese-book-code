#include<iostream>
void main()
{
	const int n=5;
	int a[n];
    int i;
	for (i=0;i<n;i++)
	{
		a[i]=i;
	}
	for (i=(n-1);i>=0; i--)
		std::cout<<a[i]<<"\n";
}
