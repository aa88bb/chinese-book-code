#include <iostream>
using namespace std;
int main()
{
	char ch[10]={'l','a','n','d','w','o','r','k','e','r'};
	for (int i=0;i<10;i++)
	{
		cout<<ch[i];
	}
	return 0;
}