/*ͬ�ַ���Ȩ��
#include<iostream>
class father
{
    private:
    int tall;
    public:
    void seta(int a){tall=a;}
    void print1(){std::cout<<"����="<<tall<<std::endl;}
};
class mother
{
    private:
    int weight;
    public:
    void setb(int b){weight=b;}
    void print2(){std::cout<<"����="<<weight<<std::endl;}
};
class son:public father,public mother
{
    private:
    int age;
    public:
    void setc(int c){age=c;}
    void print3(){print1();print2();std::cout<<"����="<<age<<std::endl;}
};
int main()
{
    son a;
    a.seta(55);
    a.setb(80);
    a.setc(78);
    a.print3();
	return 0;
}
*/


//���ַ���Ȩ��

#include<iostream>
class father
{
    private:
    int tall;
    public:
    void seta(int a){tall=a;}
    void print1(){std::cout<<"����="<<tall<<std::endl;}
};
class mother
{
    private:
    int weight;
    public:
    void setb(int b){weight=b;}
    void print2(){std::cout<<"����="<<weight<<std::endl;}
};
class son:public father,private mother
{
    private:
    int age;
    public:
    void setc(int c,int d){age=c;setb(d);}
    void print3(){print1();print2();std::cout<<"����="<<age<<std::endl;}
};
int main()
{
    son a;
    a.seta(55);
    a.setc(55,56);
    a.print3();
	return 0;
}
