#include<iostream>
using namespace std;
class human
{
    public:
    void stand(){cout<<"�����ܹ�ֱ�����ߣ�"<<endl;}
};
class father:public human
{
};
class mother:public human
{
};
class son:public mother,public father
{
};
void main()
{
    son Tom;
    Tom.mother::stand();
    Tom.father::stand();
    //Tom.human::stand();
    //Tom.stand();
}
