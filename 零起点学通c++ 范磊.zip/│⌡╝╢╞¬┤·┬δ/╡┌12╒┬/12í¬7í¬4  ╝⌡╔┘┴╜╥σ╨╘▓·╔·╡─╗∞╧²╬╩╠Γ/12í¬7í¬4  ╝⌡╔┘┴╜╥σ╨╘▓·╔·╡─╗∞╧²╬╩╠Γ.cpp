#include<iostream>
using std::cout;
class A
{
    public:
    int num(){return 1;}
};
class B:public A
{
    public:
    int num(){return 2;}
};
class C:public B
{
    public:
    int num(){return 3;}
};
class D:public C
{
    public:
    int num(){return 4;}
    int a(){return A::num();}
    int b(){return B::num();}
    int c(){return C::num();}
};
void main()
{
    D d;
    cout<<"a.num:"<<d.a()<<"\n";
    cout<<"b.num:"<<d.b()<<"\n";
    cout<<"c.num:"<<d.c()<<"\n";
    cout<<"d.num:"<<d.num()<<"\n";
}
