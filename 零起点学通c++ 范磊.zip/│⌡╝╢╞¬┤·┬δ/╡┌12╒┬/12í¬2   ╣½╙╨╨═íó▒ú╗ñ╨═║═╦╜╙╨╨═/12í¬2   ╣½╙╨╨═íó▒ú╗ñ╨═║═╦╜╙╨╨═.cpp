//������Ա
#include<iostream>
class father
{
    protected:
    int Ft,Fh;
    public:
    void SFtall(int Ftall){Ft=Ftall;}
    void SFweight(int Fweight){Fh=Fweight;}
    void coutF(){std::cout<<"����="<<Ft<<"\t"<<"����="<<Fh<< std::endl;}
};
class son:public father
{
    private:
    int SD,SB;
    public:
    void SSSD(int SSD){SD=SSD;}
    void SSSB(int SSB){SB=SSB;}
    void Cout() 
    {
        std::cout<<"����="<<Ft<<"\t"<<"����="<<Fh<<"\t\t"<<"���=" << SD 
             <<"\t\t"<<"�۳�="<<SB<<std::endl;}
    }; 
    void main()
    {
    son a;
    a.SFtall(160);
    a.SFweight(60);
    a.SSSD(80);
    a.SSSB(90);
    a.coutF();
    a.Cout();
}
