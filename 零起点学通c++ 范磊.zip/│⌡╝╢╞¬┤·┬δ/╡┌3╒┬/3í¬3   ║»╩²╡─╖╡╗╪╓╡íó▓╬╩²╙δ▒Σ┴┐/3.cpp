#include <iostream>
using namespace std;
int add(int x,int y)
{
	return x+y;
}
int main()
{
	int i=3,j=4;
	int result=add(i,j);
	cout<<"i+j="<< result <<endl;
	return 0;
}
