#include <iostream>
void main()
{
for(int x=0,y=0,z=0;x<3;x++,y++,z++)
std::cout<<"x:"<<x<<"y:"<<y<<"z:"<<z<<std::endl;
}

