#include<iostream>
int main()
{
int i=1; 
if(i<10)
goto yes;
std::cout<<"*";
i++;
goto yes;
std::cout<<"\n �������\n";
std::cout<<"*********\n";
yes:;
return 0;
}
