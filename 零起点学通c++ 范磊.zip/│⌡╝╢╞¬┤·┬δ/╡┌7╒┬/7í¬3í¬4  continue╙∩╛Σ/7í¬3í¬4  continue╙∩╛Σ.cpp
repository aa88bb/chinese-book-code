#include <iostream>
using namespace std;
int main()
{
  int i=0;
  while (i<3) 
  {
    i++;
    if(i==1) 
  { 
    continue; 
  } 
  cout<<"i��ֵΪ��"<<i<<endl;
  } 
  return 0;
}
