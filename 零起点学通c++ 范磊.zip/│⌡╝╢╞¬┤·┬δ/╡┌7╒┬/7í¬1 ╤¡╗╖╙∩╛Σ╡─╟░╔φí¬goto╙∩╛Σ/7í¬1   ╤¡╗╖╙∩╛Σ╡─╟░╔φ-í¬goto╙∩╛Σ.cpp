#include<iostream>
int main()
{
int i=1;
number: i++;
std::cout<<"*";
if(i<10)
goto number;
std::cout<<"\n �������\n";
std::cout<<"*********\n";
return 0;
}
