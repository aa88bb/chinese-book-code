#include<iostream>
using namespace std;
class A
{
   public:
   int get(){return 1;}
};
class B:public A
{
   public:
   int get(){return 2;}
};
void main()
{
   A a;
   int one=a.get();
   cout<<"a��ֵ�ǣ�"<<one<<endl;
   B b;
   one=b.get();
   cout<<"b��ֵ��:"<<one<<endl;
}
