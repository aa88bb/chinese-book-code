#include<iostream>
using namespace std;
class A
{
   public:
   virtual int get(){return 1;}
};
class B:public A
{
   public:
   int get(){return 2;}
};
void main()
{
   
	A *p;
	A a;
    B b;
	p=&a;
    int one=p->get();
    cout<<"a��ֵ�ǣ�"<<one<<endl;
   	p=&b;
    one=p->get();
    cout<<"b��ֵ��:"<<one<<endl;
}
