#include <iostream>
using namespace std;
class rectangle
{
public:
  rectangle():length(3),width(5){cout<<"������b�����Ϊ��" <<length*width
        <<endl;}
  int area(){return length*width;}
  private:
  int length;
  int width;
};
void main()
{
  rectangle b;
}
