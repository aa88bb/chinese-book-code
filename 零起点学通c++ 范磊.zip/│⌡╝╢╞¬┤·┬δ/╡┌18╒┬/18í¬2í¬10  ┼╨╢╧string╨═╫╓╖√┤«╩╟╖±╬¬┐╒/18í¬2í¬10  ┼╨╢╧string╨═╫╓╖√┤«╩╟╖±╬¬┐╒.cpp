#include <iostream>
#include <string>
using namespace std;
int main()
{
   string str="";
   if(str.empty())
   cout<<"�ַ���Ϊ�գ�";
   else
   cout<<str;
   return 0;
}
