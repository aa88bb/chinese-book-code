#include <iostream>
using namespace std;
int main()
{
	int a=2;
	a%=6;
	cout<<a<<endl;
	return 0;
}