#include<iostream>
int main()
{
using std::cout;
int a=1;
float b=2.1f;
cout<<(a>b?a:b);
return 0;
}
