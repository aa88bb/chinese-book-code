#include<iostream>
int main()
{
  using std::cout;
  using std::cin;
  char a;
  cin>>a;
  cout<<(a=(a>='A'&& a<='Z')?(a+32):a)<<"\n";
  return 0;
}
