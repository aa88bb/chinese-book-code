#include<iostream>
int main()
{
using std::cout;
using std::cin;
int a=1,b=2;
cout<<(a>b?a:b);
return 0;
}
