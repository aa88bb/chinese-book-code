#include <iostream>
using namespace std;
int main()
{
	int a=1,b=2,x=3,y=0;
	y=x=a+b;
	cout<<x;
	return 0;
}
