#include <iostream>
using namespace std;
int main()
{
	int a=(1+2)*(3+4)*5;
	cout<<a<<endl;
	return 0;
}