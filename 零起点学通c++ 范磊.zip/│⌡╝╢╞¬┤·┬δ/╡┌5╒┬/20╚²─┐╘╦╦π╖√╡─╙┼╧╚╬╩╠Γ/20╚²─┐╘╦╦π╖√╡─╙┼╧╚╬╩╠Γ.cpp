#include<iostream>
int main()
{
using std::cout;
using std::cin;
int a=1,b=2,z;
z=a>b?a:(a>b?a:b);
cout<<"z:"<<z<<"\n";
return 0;
}
