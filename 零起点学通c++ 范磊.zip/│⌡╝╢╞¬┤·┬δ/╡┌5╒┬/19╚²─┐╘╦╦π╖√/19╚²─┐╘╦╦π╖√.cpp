#include<iostream>
int main()
{
using std::cout;
using std::cin;
int a,b,z;
cout<<"������������\n";
cout<<"a:";
cin>>a;
cout<<"\n b:";
cin>>b;
cout<<"\n";
if(a>b) 
z=a;
else
z=b;
cout<<"z:"<<z<<"\n";
z=(a>b)?a:b;
cout<<"z:"<<z<<"\n";
return 0;
}
