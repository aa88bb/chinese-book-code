#include <iostream>
using namespace std;
int main()
{
	int a=1;
	cout<<a++;
	cout<<a;
	return 0;
}