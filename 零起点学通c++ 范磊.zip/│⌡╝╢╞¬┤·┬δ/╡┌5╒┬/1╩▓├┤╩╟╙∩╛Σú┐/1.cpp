#include <iostream>
int main()
{
	{
		int x,a=2,b=3;
		x=1;
		x     =    a    +     b;
	}
	return 0;
}