#include <iostream>
using namespace std;
int main()
{
	int a=99;
	if (a<10)
	{
		cout<<"aС��10\n";
	}

	return 0;
}