#include <iostream>
using namespace std;
int main()
{
	int *r,ra;
	return 0;
}