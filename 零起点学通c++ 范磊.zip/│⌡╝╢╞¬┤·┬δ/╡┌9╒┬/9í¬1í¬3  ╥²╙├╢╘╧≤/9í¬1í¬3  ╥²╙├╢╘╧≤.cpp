#include <iostream>
using namespace std;
class A 
{
public:
int get(){return i;}
void set(int x){i=x;}
private:
int i;
};
int main()
{
A a;
A &ra=a;
ra.set(123);
cout<<ra.get();
return 0;
}
