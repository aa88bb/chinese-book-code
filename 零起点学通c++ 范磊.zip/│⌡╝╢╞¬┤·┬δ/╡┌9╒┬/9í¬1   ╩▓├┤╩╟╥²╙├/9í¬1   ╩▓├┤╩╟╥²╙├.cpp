#include <iostream>
int main()
{
using namespace std;
int a;
int &ra=a;
ra=999;
cout<<"a:"<<a<<endl;
a=0;
cout<<"ra:"<<ra<<endl;
return 0;
}

