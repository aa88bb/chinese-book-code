#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
	double a=12.3456789012345;
	cout<<setprecision(15)<<a;
	return 0;
}