#include <iostream>
using namespace std;
int main()
{
	short a,b;
	a=32767;
	b=a+1;
	cout<<"a:"<<a<<"\n"<<"b:"<<b<<endl;
	return 0;
}