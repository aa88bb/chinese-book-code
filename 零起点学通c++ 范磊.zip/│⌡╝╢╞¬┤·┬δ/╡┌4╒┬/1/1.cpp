#include <iostream>
int add(int x,int y)
{
	return x+y;
}
using namespace std;
int main()
{
	int x=1,y=2;
	cout<<add(x,y);
	return 0;
}