
#include <iostream>
using namespace std;
int main()
{
	const char ch='s';
	cout<<ch;
	//PI=0;
	return 0;
}
