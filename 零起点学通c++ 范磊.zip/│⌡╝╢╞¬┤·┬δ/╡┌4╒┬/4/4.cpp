#include <iostream>
using namespace std;
int main()
{
	bool check=true;
	if (check==true)
	{
		cout<<"hello world\n";
	}
	return 0;
}