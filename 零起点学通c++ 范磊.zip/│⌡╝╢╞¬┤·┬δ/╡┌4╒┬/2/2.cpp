#include <iostream>
using namespace std;
int main()
{
	int a=35;
	cin>>a;
	return 0;
}