#include <iostream>
using namespace std;
int main()
{
	cout<<"int:"<<sizeof(int)<<endl;
	cout<<"short:"<<sizeof(short)<<endl;
	cout<<"long:"<<sizeof(long)<<endl;
	unsigned long a;
	cout<<"unsigned int:"<<sizeof(unsigned int)<<endl;
	cout<<"unsigned long:"<<sizeof(unsigned long)<<endl;
	return 0;
}