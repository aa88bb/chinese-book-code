#include <iostream>
using namespace std;
class shape
{
  public:
  shape(){}
  virtual ~shape(){}
  virtual float length(){return 0;}
  virtual float area(){return 0;}
  virtual void show(){}
  private:
};
class A :public shape
{
  public:
  A(float i,float j):w(i),l(j){}
  virtual ~A(){}
  virtual float width(){return w;}
  virtual float length(){return l;}
  virtual float area(){return w*l;}
  virtual void show(){cout<<"�����ε����Ϊ��"<<area()<<endl;}
  protected:
  float w;
  float l;
};
class B :public A
{
  public:
  B(float i,float j):A(i,j),w(i),l(j){}
  virtual ~B(){}
  virtual float width(){return w;}
  virtual float length(){return l;}
  virtual float area(){return w*l/2;}
  virtual void show(){cout<<"�����ε����Ϊ��"<<area()<<endl;}
  protected:
  float w;
  float l;
};
class C :public shape
{
  public:
  C(float j):l(j){}
  virtual ~C(){}
  virtual float length(){return l;}
  virtual float area(){return l*l*3.14;}
  virtual void show(){cout<<"Բ�����Ϊ��"<<area()<<endl;}
  protected:
  float l;
};
int main()
{
  shape *p;
  p=new A(23,34);
  p->show();
  delete p;
  p=new B(11,12);
  p->show();
  delete p;
  p=new C(45);
  p->show();
  p=new shape;//���Դ�������������Բ��ǳ����࣬����ģ��ĳ�����
  p->show();
  delete p;
  return 0;
}
