
#include <iostream>
int main()
{
	std::cout<<"��ϲ��C++\n";
	int x;
	std::cin>>x;
	std::cout<<x;
	return 0;
}


