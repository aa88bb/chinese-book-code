// GameWnd.cpp : implementation file
//

#include "game.h"
#include "GameWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// GameWnd

IMPLEMENT_DYNCREATE(GameWnd, CFrameWnd)

GameWnd::GameWnd()
{
	Create(NULL,"��������");
	bitmap=new CBitmap;
	bitmap->m_hObject=LoadImage(NULL,"1.1.bmp",IMAGE_BITMAP,93,100,LR_LOADFROMFILE);
	mdc=new CDC;
	CClientDC dc(this);
	mdc->CreateCompatibleDC(&dc);
	mdc->SelectObject(bitmap);

}

GameWnd::~GameWnd()
{
}


BEGIN_MESSAGE_MAP(GameWnd, CFrameWnd)
	//{{AFX_MSG_MAP(GameWnd)
	ON_WM_CREATE()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// GameWnd message handlers


int GameWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	// TODO: Add your specialized creation code here
	
	return 0;
}

void GameWnd::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	dc.BitBlt(0,0,93,100,mdc,0,0,SRCCOPY);
	// TODO: Add your message handler code here
	
	// Do not call CFrameWnd::OnPaint() for painting messages
}
