// GameApp.h: interface for the GameApp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMEAPP_H__CC14D17A_976A_4B7D_8EB0_DBE855D5CF20__INCLUDED_)
#define AFX_GAMEAPP_H__CC14D17A_976A_4B7D_8EB0_DBE855D5CF20__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class GameApp : public CWinApp  
{
public:
	GameApp();
	virtual ~GameApp();
	BOOL InitInstance();

};

#endif // !defined(AFX_GAMEAPP_H__CC14D17A_976A_4B7D_8EB0_DBE855D5CF20__INCLUDED_)
