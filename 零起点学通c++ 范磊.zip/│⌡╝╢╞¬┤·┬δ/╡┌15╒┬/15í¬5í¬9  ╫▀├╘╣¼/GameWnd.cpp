// GameWnd.cpp : implementation file
//

#include "game.h"
#include "GameWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// GameWnd

IMPLEMENT_DYNCREATE(GameWnd, CFrameWnd)
int maze[8][8]={
				1,1,1,1,1,1,2,1,   	//��1�У�ֵΪ2��Ԫ�ش������
				3,0,0,1,0,0,0,1,		//��2�У�ֵΪ3��Ԫ�ش�������
				1,1,0,0,0,1,1,1,		//��3��
				1,0,0,1,0,0,0,1,		//��4��
				1,1,1,1,0,1,1,1,		//��5��
				1,0,0,0,0,0,0,1,		//��6��
				1,0,1,0,1,0,0,1,		//��7��
				1,1,1,1,1,1,1,1		//��8��
};

GameWnd::GameWnd()
{
	Create(NULL,"��ͼ�Ӵ�",WS_OVERLAPPEDWINDOW,CRect(0,0,744,800));
	mdc=new CDC;
	char ch[8];
	for(int i=0;i<4;i++)
	{
	  for(int j=0;j<4;j++)
	  {
		  sprintf(ch,"%d.%d.bmp",i+1,j+1);
		  bitmap[i][j]=new CBitmap;
		  bitmap[i][j]->m_hObject=LoadImage(NULL, ch, IMAGE_BITMAP, 93, 100, LR_LOADFROMFILE);
	  }
	}
	CPaintDC dc(this);

	mdc->CreateCompatibleDC(&dc);
	mdc->SelectObject(bitmap[0][0]);
	dir=0;index=0;	x=0;y=0,m=0,n=0,k=0,p=0;
	for( i=0;i<8;i++)
	{
      for (int j=0;j<8;j++)
	  {
        if (maze[i][j]==2)
		{
           m=i;
           n=j;
           break;
		}
	  }
	}
  wall=new CBitmap;  			//����һ��λͼ����
  wall->m_hObject=LoadImage(NULL,"wall.bmp",IMAGE_BITMAP,93,100,LR_LOADFROMFILE);  					//װ��ǽ��ͼ"wall.bmp"
  start=true;
}

GameWnd::~GameWnd()
{
}


BEGIN_MESSAGE_MAP(GameWnd, CFrameWnd)
	//{{AFX_MSG_MAP(GameWnd)
	ON_WM_CREATE()
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// GameWnd message handlers


int GameWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	// TODO: Add your specialized creation code here
	SetTimer(1,100,NULL);
	return 0;
}

void GameWnd::OnPaint() 
{
	CPaintDC dc(this); // OnPaint()����ֻ������һ��
	dc.BitBlt(0,0,93,100,mdc,0,0,SRCCOPY);
	// Do not call CFrameWnd::OnPaint() for painting messages
}

void GameWnd::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
  if (start)
	{
		Start();
	}
	CFrameWnd::OnTimer(nIDEvent);
}

void GameWnd::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	CClientDC dc(this);
	dc.BitBlt(n*93+x,m*100+y,93,100,mdc,0,0,WHITENESS);
	k=(n*93+x)/93;
	p=(m*100+y)/100;
	if (maze[p][k]==3)
	{
		dc.TextOut(120,350,"��ȥ��");
	}
	if (nChar==VK_DOWN)
	{
      y+=100;
      k=(n*93+x)/93;
      p=(m*100+y)/100;
      if (maze[p][k]==1)
	  {
        y-=100;
	  }
      if(dir==0)
	  {
        index++;
        if (index==4)
		{
         index=0;
		}
	  }
	  else
	  {
        index=0;
        dir=0;
	  }
	}

//�������ϼ�ʱ�Ĵ������£�
   	if (nChar==VK_UP)
	{
	    y-=100;
	    k=(n*93+x)/93;
	    p=(m*100+y)/100;
	    if (maze[p][k]==1)
		{
	      y+=100;
		}

      	if (dir==3)		  	//�ж���һ���Ƿ������ϼ�
      	{
      		index++;
      		if (index==4)
      		{
      			index=0;
      		}
      	}
      	else
      	{
      		index=0;
      		dir=3;        	//����Ϊ��
      	}
      }
//���������ʱ�Ĵ������£�
	if (nChar==VK_LEFT)		//���簴�������
	{
		x-=93;
		k=(n*93+x)/93;
		p=(m*100+y)/100;
		if (maze[p][k]==1)
		{
			x+=93;
		}
		if (dir==1)		//�ж���һ���Ƿ��������
		{
			index++;
			if (index==4)
			{
				index=0;
			}
		}
		else
		{
			index=0;
			dir=1;		//����Ϊ��
		}
		
	}
//�������Ҽ�ʱ�Ĵ������£�
	if (nChar==VK_RIGHT)   			//���簴�����Ҽ�
		{
			x+=93;
			k=(n*93+x)/93;
			p=(m*100+y)/100;
			if (maze[p][k]==1)
			{
				x-=93;
			}
			if (dir==2)
			{
				index++;
				if (index==4) 	//�ж���һ���Ƿ������Ҽ�
				{
					index=0;
				}
			}
			else
			{
				index=0;
				dir=2;			//����Ϊ��
			}
			
		}
	mdc->SelectObject(bitmap[dir][index]);
	dc.BitBlt(n*93+x,m*100+y,93,100,mdc,0,0,SRCCOPY);
	CFrameWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}

void GameWnd::Start()
{
  CClientDC dc(this);
  mdc->SelectObject(wall);
  for (int i=0;i<8;i++)
  {
    for (int j=0;j<8;j++)
    {
      if (maze[i][j]==1)
      {
        dc.BitBlt(j*93,i*100,93,100,mdc,0,0,SRCCOPY);
      }
    }
  }
  mdc->SelectObject(bitmap[0][0]);
  dc.BitBlt(n*93,m*100,93,100,mdc,0,0,SRCCOPY);
  start=false;

}
