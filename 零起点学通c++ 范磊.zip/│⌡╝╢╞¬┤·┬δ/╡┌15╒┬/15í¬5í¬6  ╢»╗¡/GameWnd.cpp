// GameWnd.cpp : implementation file
//

#include "game.h"
#include "GameWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// GameWnd

IMPLEMENT_DYNCREATE(GameWnd, CFrameWnd)

GameWnd::GameWnd()
{
	Create(NULL,"��������");
	mdc=new CDC;
	char ch[8];
	for(int i=0;i<4;i++)
	{
	  for(int j=0;j<4;j++)
	  {
		  sprintf(ch,"%d.%d.bmp",i+1,j+1);
		  bitmap[i][j]=new CBitmap;
		  bitmap[i][j]->m_hObject=LoadImage(NULL, ch, IMAGE_BITMAP, 93, 100, LR_LOADFROMFILE);
	  }
	}
	CPaintDC dc(this);

	mdc->CreateCompatibleDC(&dc);
	mdc->SelectObject(bitmap[0][0]);
	dir=0;index=0;	
}

GameWnd::~GameWnd()
{
}


BEGIN_MESSAGE_MAP(GameWnd, CFrameWnd)
	//{{AFX_MSG_MAP(GameWnd)
	ON_WM_CREATE()
	ON_WM_PAINT()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// GameWnd message handlers


int GameWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	// TODO: Add your specialized creation code here
	SetTimer(1,100,NULL);
	return 0;
}

void GameWnd::OnPaint() 
{
	CPaintDC dc(this); // OnPaint()����ֻ������һ��
	
	// Do not call CFrameWnd::OnPaint() for painting messages
}

void GameWnd::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
CClientDC dc(this);
  if (dir>=4)
  {
    dir=0;
  }
  if (index<4)
  {
    mdc->SelectObject(bitmap[dir][index]);
    index++;
  }
  else
  {
    index=0;
    dir++;
    mdc->SelectObject(bitmap[dir][index]);
  }
  dc.BitBlt(0,0,93,100,mdc,0,0,SRCCOPY);


	CFrameWnd::OnTimer(nIDEvent);
}
