#if !defined(AFX_GAMEWND_H__047364A1_3860_4CBB_B33B_0278745C7A60__INCLUDED_)
#define AFX_GAMEWND_H__047364A1_3860_4CBB_B33B_0278745C7A60__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GameWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// GameWnd frame

class GameWnd : public CFrameWnd
{
	DECLARE_DYNCREATE(GameWnd)
public:
	GameWnd();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(GameWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	void Go();
	void Start();
	CBitmap* bitmap[4][4];
	CBitmap *wall;//����һ��ָ��λͼ�����ָ�룺
	CDC*mdc;
	virtual ~GameWnd();
    int dir;
    int index;
	int x,y;
	int m,n,k,p,number;
	bool start,go;
	RECT Crect;
	// Generated message map functions
	//{{AFX_MSG(GameWnd)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GAMEWND_H__047364A1_3860_4CBB_B33B_0278745C7A60__INCLUDED_)
