// GameWnd.cpp : implementation file
//

#include "game.h"
#include "GameWnd.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// GameWnd

IMPLEMENT_DYNCREATE(GameWnd, CFrameWnd)
int maze[8][8]={
				1,1,1,1,1,1,2,1,   	//��1�У�ֵΪ2��Ԫ�ش������
				3,0,0,1,0,0,0,1,		//��2�У�ֵΪ3��Ԫ�ش�������
				1,1,0,0,0,1,1,1,		//��3��
				1,0,0,1,0,0,0,1,		//��4��
				1,1,1,1,0,1,1,1,		//��5��
				1,0,0,0,0,0,0,1,		//��6��
				1,0,1,0,1,0,0,1,		//��7��
				1,1,1,1,1,1,1,1		//��8��
};
struct list    				//�ڴ���������һ��ȫ�������ṹlist
{
	int m;					//��ڸ������
	int n;					//��ڸ������
	int x;					//�᷽����ƶ�ֵ
	int y;					//�ݷ�����ƶ�ֵ
	struct list*next;   		//ָ����һ�����
	struct list*back;		//ָ����һ�����
	CBitmap*bitmap;			//λͼָ�룬����ָ��ý�����������ͼƬ
};
list*ptr,*preptr,*first;
GameWnd::GameWnd()
{
	Create(NULL,"��ͼ�Ӵ�",WS_OVERLAPPEDWINDOW,CRect(0,0,744,800));
	mdc=new CDC;
	char ch[8];
	for(int i=0;i<4;i++)
	{
	  for(int j=0;j<4;j++)
	  {
		  sprintf(ch,"%d.%d.bmp",i+1,j+1);
		  bitmap[i][j]=new CBitmap;
		  bitmap[i][j]->m_hObject=LoadImage(NULL, ch, IMAGE_BITMAP, 93, 100, LR_LOADFROMFILE);
	  }
	}
	CPaintDC dc(this);

	mdc->CreateCompatibleDC(&dc);
	mdc->SelectObject(bitmap[0][0]);
	dir=0;index=0;	x=0;y=0,m=0,n=0,k=0,p=0,number=0,go=false;
	for( i=0;i<8;i++)
	{
      for (int j=0;j<8;j++)
	  {
        if (maze[i][j]==2)
		{
           m=i;
           n=j;
           break;
		}
	  }
	}
  wall=new CBitmap;  			//����һ��λͼ����
  wall->m_hObject=LoadImage(NULL,"wall.bmp",IMAGE_BITMAP,93,100,LR_LOADFROMFILE);  					//װ��ǽ��ͼ"wall.bmp"
  start=true;
  ptr=(list*)malloc(sizeof(list));
  ptr->m=m;   					//����ڸ������������һ������m��Ա
  ptr->n=n;					    //����ڸ������������һ������n��Ա
  ptr->bitmap=bitmap[0][0];	    //��ͷ����bitmapָ��ָ�����������ߵĵ�һ��ͼƬ
  ptr->next=NULL;				//��ǰ����ֻ����һ����㣬����next��Ϊ��
  ptr->back=NULL;				//��ǰ����ֻ����һ����㣬����back��Ϊ��
  first=ptr;//��first�������1�����ĵ�ַ
}

GameWnd::~GameWnd()
{
}


BEGIN_MESSAGE_MAP(GameWnd, CFrameWnd)
	//{{AFX_MSG_MAP(GameWnd)
	ON_WM_CREATE()
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// GameWnd message handlers


int GameWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	// TODO: Add your specialized creation code here
	SetTimer(1,100,NULL);
	return 0;
}

void GameWnd::OnPaint() 
{
	CPaintDC dc(this); // OnPaint()����ֻ������һ��
	dc.BitBlt(0,0,93,100,mdc,0,0,SRCCOPY);
	// Do not call CFrameWnd::OnPaint() for painting messages
}

void GameWnd::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
  if (start)
  {
    Start();
  }
  else
  {
    if (go)
    Go();
  }
	CFrameWnd::OnTimer(nIDEvent);
}

void GameWnd::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	CClientDC dc(this);
	dc.BitBlt(n*93+x,m*100+y,93,100,mdc,0,0,WHITENESS);
	k=(n*93+x)/93;
	p=(m*100+y)/100;
	if (maze[p][k]==3)
	{
		dc.TextOut(120,350,"��ȥ��");
	}
	//�������¼�
	if (nChar==VK_DOWN)
	{
    	y+=100;
		k=(n*93+x)/93;
		p=(m*100+y)/100;
		if (maze[p][k]==1)
		{
			y-=100;
		}
		if (dir==0)
		{
			index++;
			if (index==4)
			{
				index=0;
			}
		}
		else
		{
			index=0;
			dir=0;
		}
		ptr->next=(list*)malloc(sizeof(list));
		ptr->next->m=m;
		ptr->next->n=n;
		ptr->next->x=x;
		ptr->next->y=y;
		ptr->next->bitmap=bitmap[dir][index];
		preptr=ptr;
		ptr->next->next=NULL;
		ptr=ptr->next;
        ptr->back=preptr;
	}


	//�������ϼ�
	if (nChar==VK_UP)
	{
		y-=100;
		k=(n*93+x)/93;
		p=(m*100+y)/100;
		if(maze[p][k]==1)
		{
			y+=100;
		}
		if (dir==3)
		{
			index++;
			if (index==4)
			{
				index=0;
			}
		}
		else
		{
			index=0;
			dir=3;
		}
		ptr->next=(list*)malloc(sizeof(list));
		ptr->next->m=m;
		ptr->next->n=n;
		ptr->next->x=x;
		ptr->next->y=y;
		ptr->next->bitmap=bitmap[dir][index];
		preptr=ptr;
		ptr->next->next=NULL;
		ptr=ptr->next;
		ptr->back=preptr;
	}
	
	//���������	
	if (nChar==VK_LEFT)
	{
		x-=93;
		k=(n*93+x)/93;
		p=(m*100+y)/100;
		if(maze[p][k]==1)
		{
			x+=93;
		}
		if (dir==1)
		{
			index++;
			if (index==4)
			{
				index=0;
			}
		}
		else
		{
			index=0;
			dir=1;
		}
		ptr->next=(list*)malloc(sizeof(list));
		ptr->next->m=m;
		ptr->next->n=n;
		ptr->next->x=x;
		ptr->next->y=y;
		ptr->next->bitmap=bitmap[dir][index];
		preptr=ptr;
		ptr->next->next=NULL;
		ptr=ptr->next;
		ptr->back=preptr;
	}
	
	 //�������Ҽ�
	if (nChar==VK_RIGHT)
	{
		x+=93;
		k=(n*93+x)/93;
		p=(m*100+y)/100;
		if(maze[p][k]==1)
		{
			x-=93;
		}
		if (dir==2)
		{
			index++;
			if (index==4)
			{
				index=0;
			}
		}
		else
		{
			index=0;
			dir=2;
		}
		ptr->next=(list*)malloc(sizeof(list));
		ptr->next->m=m;
		ptr->next->n=n;
		ptr->next->x=x;
		ptr->next->y=y;
		ptr->next->bitmap=bitmap[dir][index];
		preptr=ptr;
		ptr->next->next=NULL;
		ptr=ptr->next;
		ptr->back=preptr;
	}

	//���ڵĳ���������£�
	k=(n*93+x)/93;
	p=(m*100+y)/100;
	if (maze[p][k]==3)
	{
		dc.TextOut(120,350,"��ȥ��");
		ptr->next=(list*)malloc(sizeof(list));
		ptr->next->m=m;
		ptr->next->n=n;
		ptr->next->x=x;
		ptr->next->y=y;
		ptr->next->bitmap=bitmap[dir][index];
		preptr=ptr;
		ptr->next->next=NULL;
		ptr=ptr->next;
		ptr->back=preptr;
		go=true;
		return;
	}
	mdc->SelectObject(bitmap[dir][index]);
	dc.BitBlt(n*93+x,m*100+y,93,100,mdc,0,0,SRCCOPY);
	CFrameWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}

void GameWnd::Start()
{
  CClientDC dc(this);
  mdc->SelectObject(wall);
  for (int i=0;i<8;i++)
  {
    for (int j=0;j<8;j++)
    {
      if (maze[i][j]==1)
      {
        dc.BitBlt(j*93,i*100,93,100,mdc,0,0,SRCCOPY);
      }
    }
  }
  mdc->SelectObject(bitmap[0][0]);
  dc.BitBlt(n*93,m*100,93,100,mdc,0,0,SRCCOPY);
  start=false;

}

void GameWnd::Go()
{
 CClientDC dc(this);
  mdc->SelectObject(wall);
  for (int i=0;i<8;i++)
  {
    for (int j=0;j<8;j++)
    {
      if (maze[i][j]==1)
      {
        dc.BitBlt(j*93,i*100,93,100,mdc,0,0,SRCCOPY);
      }
    }	
  }
  mdc->SelectObject(first->bitmap);
  if (number==0)
  {	
   dc.BitBlt(first->n*93+first->x,first->m*100+first->y,93,100,
   mdc,0,0,SRCCOPY);
  }
  else
  {
   dc.BitBlt(first->back->n*93+first->back->x,first->back->m*100+
   first->back->y,93,100,mdc,0,0,WHITENESS);
   dc.BitBlt(first->n*93+first->x,first->m*100+first->y,93,100,mdc,0,0,SRCCOPY);
  }
  number++;


  if (first->next==NULL)
  {
    go=false;
  }
  else
  first=first->next;

}
