// GameApp.cpp: implementation of the GameApp class.
//
//////////////////////////////////////////////////////////////////////

#include "game.h"
#include "GameWnd.h"
#include "GameApp.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
GameApp myapp;
BOOL GameApp::InitInstance()
{
	m_pMainWnd=new GameWnd;
	m_pMainWnd->ShowWindow(m_nCmdShow);
	m_pMainWnd->UpdateWindow();
	return TRUE;
}
GameApp::GameApp()
{

}

GameApp::~GameApp()
{

}
