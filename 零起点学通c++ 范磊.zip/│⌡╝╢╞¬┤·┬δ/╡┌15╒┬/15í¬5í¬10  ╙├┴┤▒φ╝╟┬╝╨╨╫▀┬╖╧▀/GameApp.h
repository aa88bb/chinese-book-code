// GameApp.h: interface for the GameApp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMEAPP_H__46ECD2CA_C924_4C06_9CC9_4B85D015F385__INCLUDED_)
#define AFX_GAMEAPP_H__46ECD2CA_C924_4C06_9CC9_4B85D015F385__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class GameApp : public CWinApp  
{
public:
	BOOL InitInstance();
	GameApp();
	virtual ~GameApp();

};

#endif // !defined(AFX_GAMEAPP_H__46ECD2CA_C924_4C06_9CC9_4B85D015F385__INCLUDED_)
