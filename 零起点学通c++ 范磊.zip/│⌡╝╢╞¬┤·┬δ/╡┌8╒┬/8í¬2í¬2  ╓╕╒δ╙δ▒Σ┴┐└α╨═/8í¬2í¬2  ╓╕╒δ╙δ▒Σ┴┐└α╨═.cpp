#include <iostream>
using namespace std;
int main()
{
float *p=0;
			   
float a=3.14f;			   
p=&a;
return 0;
}
