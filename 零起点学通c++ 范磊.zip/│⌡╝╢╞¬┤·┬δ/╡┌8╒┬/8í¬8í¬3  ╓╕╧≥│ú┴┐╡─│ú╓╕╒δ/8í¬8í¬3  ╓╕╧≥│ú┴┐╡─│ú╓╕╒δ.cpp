#include <iostream>
using namespace std;
class A 
{
public:
int get()const{return i;}
void set(int x){i=x;}
private:
int i;
};
int main()
{
const A* const p=new A;
//p=p+1;
//p->set(11);
cout<<p->get();
return 0;
}
