#include <iostream>
using namespace std;
class A 
{
public :
int get()const{return i;}
void set(int x){i=x;}
private:
int i;
};
int main()
{
A*a=new A;
a->set(1);
cout<<a->get()<<endl;
delete a;
return 0;
}
