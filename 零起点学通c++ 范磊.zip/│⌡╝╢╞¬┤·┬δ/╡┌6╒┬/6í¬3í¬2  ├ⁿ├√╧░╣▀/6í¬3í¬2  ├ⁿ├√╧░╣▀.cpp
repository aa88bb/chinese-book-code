#include <iostream>
class Human
{
public:
void GetStature ();
void GetWeight ();
private:
int stature;
int weight;
};
int main()
{
	return 0;
}